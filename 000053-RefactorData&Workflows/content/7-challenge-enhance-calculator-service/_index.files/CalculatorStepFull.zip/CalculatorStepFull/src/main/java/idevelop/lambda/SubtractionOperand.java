package idevelop.lambda;

public class SubtractionOperand implements IOperator {

	@Override
	public String getName() {
		
		return "Subtraction";
		
	}
	
	@Override
	public double calculate(double operandA, double operandB) {
		
		return operandA - operandB;
		
	}
	
}
