package idevelop.lambda;

public interface IOperator {
	
	public String getName();
	public double calculate(double operandA, double operandB);


}
