package idevelop.model;

public class CalculationResult {
	
	public CalculationResult()
	{
	}
	
	public CalculationResult(double result)
	{
		this.result = result;
	}

	private double result;

	public double getResult() {
		return result;
	}

	public void setResult(double value) {
		this.result = value;
	}

	@Override
	public String toString(){
		return "result="+getResult();
	}
}
