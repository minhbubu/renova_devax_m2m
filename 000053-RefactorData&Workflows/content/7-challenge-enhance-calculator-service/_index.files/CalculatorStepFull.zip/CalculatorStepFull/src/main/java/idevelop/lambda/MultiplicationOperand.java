package idevelop.lambda;

public class MultiplicationOperand implements IOperator {

	@Override
	public String getName() {
		
		return "Multiplying";
		
	}
	
	@Override
	public double calculate(double operandA, double operandB) {
		
		return operandA * operandB;
		
	}
	
}
