package idevelop.lambda;

public class AdditionOperand implements IOperator {

	@Override
	public String getName() {
		
		return "Adding";
		
	}
	
	@Override
	public double calculate(double operandA, double operandB) {
		
		return operandA + operandB;
		
	}
	
}
