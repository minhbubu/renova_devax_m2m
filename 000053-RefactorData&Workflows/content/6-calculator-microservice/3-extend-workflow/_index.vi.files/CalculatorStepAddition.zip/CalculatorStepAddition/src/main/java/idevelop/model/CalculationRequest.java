package idevelop.model;

public class CalculationRequest {
	
	private CalculatorOperators enumOperator = CalculatorOperators.NotSupported;
	private double[] operands = {};
	private String operator = "";
	
	public CalculationRequest()
	{
		
	}
	
	public CalculationRequest(String operator, double[] operands)
	{
		this.operator = operator;
		this.setOperands(operands);
	}

	public String getRawOperator()
	{
		return this.operator;
	}
	
	public void setOperator(String operator)
	{
		this.operator = operator;
	}

	public CalculatorOperators getOperator()
	{		
		switch ( this.operator )
		{
			case "add":
			{
				this.enumOperator = CalculatorOperators.Addition;
			}
			break;
			default:
			{
				this.enumOperator = CalculatorOperators.NotSupported;
			}
			break;
		}
		
		return this.enumOperator;
	}
	
	public double[] getOperands()
	{
		return this.operands;
	}

	public void setOperands(double[] operands) {
		this.operands = operands;
	}
}
