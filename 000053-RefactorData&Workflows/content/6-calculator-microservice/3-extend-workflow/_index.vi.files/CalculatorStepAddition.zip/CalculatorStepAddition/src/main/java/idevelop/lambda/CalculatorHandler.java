package idevelop.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import idevelop.model.CalculationResult;
import idevelop.model.CalculationRequest;

public class CalculatorHandler implements RequestHandler<CalculationRequest, CalculationResult> {

	@Override
	public CalculationResult handleRequest(CalculationRequest request, Context context) {
		
		CalculationResult result = new CalculationResult();
		LambdaLogger logger = context.getLogger();
		
		logger.log("Starting " + this.getClass().getName() + " Lambda\n");
		
		logger.log("Operator (RAW) is " + request.getRawOperator() );
		logger.log("Operator (PARSED) is " + request.getOperator().toString() );
		logger.log("Operand count is " + request.getOperands().length );

		IOperator implOperator = null;
		
		switch ( request.getOperator() )
		{
			case Addition:
			{
				implOperator = new AdditionOperand();
			}
			break;
			
			default:
				break;			
		}
		
		double calcValue = 0;
		
		if ( implOperator != null )
		{			
			boolean isFirst = true;
			
			for ( double operand : request.getOperands() )
			{
				if ( isFirst )
				{
					isFirst = false;
					calcValue = operand;
					System.out.println("Setting initial value " + operand);
				}
				else
				{
					calcValue = implOperator.calculate(calcValue, operand);
					System.out.println("          Subtotal " + calcValue);
				}
			}
			
			result.setResult(calcValue);
			
			return result;
		}
		else
		{
			throw new UnsupportedOperationException("Operand is not supported");
		}
	}
}
