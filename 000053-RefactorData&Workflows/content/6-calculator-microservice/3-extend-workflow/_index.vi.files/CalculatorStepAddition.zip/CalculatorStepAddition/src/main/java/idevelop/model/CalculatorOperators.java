package idevelop.model;

public enum CalculatorOperators {
	
	NotSupported,
	Addition	
}
