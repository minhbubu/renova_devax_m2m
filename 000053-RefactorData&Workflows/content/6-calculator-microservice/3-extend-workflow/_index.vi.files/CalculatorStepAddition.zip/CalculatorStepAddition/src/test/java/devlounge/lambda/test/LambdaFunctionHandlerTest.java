package devlounge.lambda.test;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;

import idevelop.lambda.CalculatorHandler;
import idevelop.model.CalculationResult;
import idevelop.model.CalculationRequest;

/**
 * A simple test harness for locally invoking your Lambda function handler.
 */
public class LambdaFunctionHandlerTest {

    @BeforeClass
    public static void createInput() throws IOException {

    }

    private Context createContext() {
        TestContext ctx = new TestContext();

        // TODO: customize your context here if needed.
        ctx.setFunctionName("Your Function Name");

        return ctx;
    }

    @Test
    public void testLambdaFunctionHandler() {
    	
    	Context ctx = createContext();
    	ctx.getLogger().log("TEST::testLambdaFunctionHandler()");
    	
    	double[] dblOperands = {1,2,3,4,5};
    	
        CalculatorHandler handler = new CalculatorHandler();
        CalculationRequest request;                
        CalculationResult result;
        
        //
        // Addition
        //
        request = new CalculationRequest("add", dblOperands);
        result = handler.handleRequest(request, ctx);
        System.out.println("Result = " + result.getResult());
        Assert.assertTrue(result.getResult() == 15.0);

    }
}
