package travelbuddy.spring.dao;

import java.util.List;

import travelbuddy.spring.model.HotelSpecial;

public interface HotelSpecialDAO {

	public List<HotelSpecial> findAll();
	public HotelSpecial findById(int id);
}
